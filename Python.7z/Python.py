import random

def rps_game():
    options = ['rock', 'paper', 'scissors']
    rules = {
        'rock': 'scissors',
        'paper': 'rock',
        'scissors': 'paper'
    }

    print("🎮 Rock, Paper, Scissors Game")
    print("Type 'rock', 'paper', or 'scissors'. Type 'exit' to quit.\n")

    while True:
        user = input("You: ").lower()
        if user == 'exit':
            print("👋 Game Over! Thanks for playing.")
            break

        if user not in options:
            print("⚠️ Invalid input. Please choose: rock, paper, or scissors.")
            continue

        ai = random.choice(options)
        print(f"🤖 AI chose: {ai}")

        if user == ai:
            print("🤝 It's a draw!\n")
        elif rules[user] == ai:
            print("🎉 You win!\n")
        else:
            print("😈 AI wins!\n")

# Run the game
rps_game()